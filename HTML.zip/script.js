class StartExec
{
    constructor ()
    {
        this.parentElement=document.getElementById("parentDiv");
        this.initHome(this.parentElement);
    }
    initHome(parentElement) {
        for(let brand in product_data)
        {
            parentElement.innerHTML += "Manufacturer: " + brand + "<br />";
            for(let dev_det in product_data[brand])
            {
                switch(dev_det)
                {
                    case "model":
                        parentElement.innerHTML += "Model: " + product_data[brand][dev_det] + "<br />";
                        break;
                    case "variant":
                        parentElement.innerHTML += "Variant: " + product_data[brand][dev_det] + "<br />";
                        break;
                    case "storage":
                        parentElement.innerHTML += "Storage: " + product_data[brand][dev_det] + "<br />";
                        break;
                    case "ram":
                        parentElement.innerHTML += "RAM: " + product_data[brand][dev_det] + "<br />";
                        break;
                }
                if(typeof(product_data[brand][dev_det])=="object")
                {
                    for(let img in product_data[brand][dev_det])
                        parentElement.innerHTML += "<img height=250 width=300 src='res/" + product_data[brand][dev_det][img] + "' />";
                }
            }
            parentElement.innerHTML += "<br /><br /><br /><br />";
        }
    }
}